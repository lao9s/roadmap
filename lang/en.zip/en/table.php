<?php

return [
    'title' => 'Title',
    'total-votes' => 'Votes',
    'project' => 'Project',
    'board' => 'Board',
    'content' => 'Content',
    'item' => 'Item',
    'created_at' => 'Created at',
    'updated_at' => 'Updated at',
    'last_comment_posted_at' => 'Last comment posted at',
];
