<?php

return [
    'created' => 'created the item',
    'linked-to-issue' => 'linked item to issue #:issue_number on GitHub',
    'moved-to-project' => 'moved item to project :project',
    'moved-to-board' => 'moved item to board :board',
    'made-private' => 'made item private',
    'made-public' => 'made item public',
    'pinned' => 'pinned the item',
    'unpinned' => 'unpinned the item',

    'unknown-user' => 'Unknown user',
];
