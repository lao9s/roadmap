<?php

return [
    'link-expired.title' => 'Link expired',
    'link-expired' => 'The link you clicked has expired or otherwise has become invalid. Please try again.',
];
