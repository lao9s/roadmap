<?php

return [
    'changelog' => 'Changelog',
    'all-caught-up-title' => 'Nothing here yet',
    'all-caught-up-description' => 'There aren\'t any changes added to this changelog',
    'included-items' => 'Included items'
];
