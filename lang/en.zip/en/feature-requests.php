<?php

return [
    'submit-feature-request' => 'Submit a Feature Request',
    'all-feature-requests' => 'All Feature Requests',
    'all-feature-requests-description' => "Here you'll be able to find all requested features by our users. You can vote for them and we'll implement the most popular ones.",
    'my-feature-requests' => 'My Feature Requests',
];
