<?php

return [
    'votes' => 'vote|votes',
    'total-votes' => '{0} no votes yet|{1} 1 total vote|[2,*] :votes total votes',
    'comments' => 'comment|comments'
];
