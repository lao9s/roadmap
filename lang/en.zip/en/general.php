<?php

return [
    'dashboard' => 'Home',
    'navbar-search' => 'CMD + / to search',

    'recent-items' => 'Recent feature requests',
    'recent-comments' => 'Recent comments',

    'close' => 'Close',
    'save' => 'Save',
];
