<?php

return [
    'projects' => 'Projects',
    'no-projects' => 'There are no projects.',
    'select-hidden-projects' => 'You can only select projects where there private option is enabled.',
];
