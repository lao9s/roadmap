<?php

return [
    'create-item' => [
        'name' => 'Submit a Feature Request',
        'description' => '',
    ],
    'view-item' => [
        'name' => 'View item',
        'description' => 'View an item',
    ],
    'profile' => [
        'name' => 'Profile',
        'description' => 'View your profile',
    ],
    'logout' => [
        'name' => 'Logout',
        'description' => 'Logout out of your account',
    ],
];
